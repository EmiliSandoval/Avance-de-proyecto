package lexemas;

import lexemas.Buscar;


public class Go {
 public static void main(String[] args) {
        Buscar ER = new Buscar();
        ER.setVisible(true);
    }
    
}